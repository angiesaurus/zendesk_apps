﻿from bottle import route, template, redirect, static_file, error, request, response, run


@route('/home')
def show_home():
    return template('home')


@route('/')
def handle_root_url():
    redirect('/home')


@route('/zendesk_profile')
def make_request():
    # Get user data
    profile_data = {'name': 'Lea Lee', 'role': 'admin'}
    return template('details', data=profile_data)


@route('/css/<filename>')
def send_css(filename):
    return static_file(filename, root='static/css')


@error(404)
def error404(error):
    return template('error', error_msg='404 error. Nothing to see here')


run(host='localhost', port=8080, debug=True)